const typed= new Typed('.multiple-text',{
    strings:['Full Stack Developer','Full Stack Developer','Full Stack Developer'],
    typeSpeed:100,
    backSpeed:100,
    backDelay:1000,
    loop:true
    
});

// document.getElementById('run').style.color:red;

const sr=ScrollReveal({
    distance:'40px',
    duration:2500,
    reset:true,
});


sr.reveal('.skill1',{delay:200, origin:'bottom'});
sr.reveal('.Project-sec',{delay:200, origin:'top'});

